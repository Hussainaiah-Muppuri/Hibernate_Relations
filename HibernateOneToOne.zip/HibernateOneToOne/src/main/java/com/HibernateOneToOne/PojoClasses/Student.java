package com.HibernateOneToOne.PojoClasses;

import java.util.List;
import java.util.Set;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.JoinTable;
import jakarta.persistence.ManyToMany;
import jakarta.persistence.OneToMany;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;

@Entity
@Table(name = "student")
public class Student {
 
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;
 
     private String firstName;
 
     private String lastName;
 
     private String email;
     
     private String fatherName;
 
     
    @OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "student_detail_id")
    private StudentDetail studentDetail;
    

	@OneToMany(fetch = FetchType.LAZY, mappedBy = "student", cascade = CascadeType.ALL)
	private List<Address> address;
	
	
	@ManyToMany(fetch = FetchType.LAZY, cascade = { CascadeType.PERSIST, CascadeType.MERGE, CascadeType.REFRESH,
			CascadeType.DETACH })
	@JoinTable(name = "StudentDetails_College_Details_Map", joinColumns = @JoinColumn(name = "student_Id"),
	inverseJoinColumns = @JoinColumn(name = "college_Id"))
	private Set<CollegeDetails> collegeDetails;
 
    public Student() {}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public StudentDetail getStudentDetail() {
		return studentDetail;
	}

	public void setStudentDetail(StudentDetail studentDetail) {
		this.studentDetail = studentDetail;
	}

	public void setAddress(List<Address> address) {
		this.address = address;
	}

	public String getFatherName() {
		return fatherName;
	}

	public void setFatherName(String fatherName) {
		this.fatherName = fatherName;
	}

	public List<Address> getAddress() {
		return address;
	}

	public Set<CollegeDetails> getCollegeDetails() {
		return collegeDetails;
	}

	public void setCollegeDetails(Set<CollegeDetails> collegeDetails) {
		this.collegeDetails = collegeDetails;
	}

	public Student(Long id, String firstName, String lastName, String email, String fatherName,
			StudentDetail studentDetail, List<Address> address, Set<CollegeDetails> collegeDetails) {
		super();
		this.id = id;
		this.firstName = firstName;
		this.lastName = lastName;
		this.email = email;
		this.fatherName = fatherName;
		this.studentDetail = studentDetail;
		this.address = address;
		this.collegeDetails = collegeDetails;
	}
	
}