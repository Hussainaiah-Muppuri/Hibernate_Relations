package com.HibernateOneToOne.PojoClasses;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "student_details")
public class StudentDetail {
 
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;
 
    private String college;
 
    private int noStudentinClass;
    
    private String location;
    
    
    public StudentDetail() {	
    }

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getCollege() {
		return college;
	}

	public void setCollege(String college) {
		this.college = college;
	}

	public int getNoStudentinClass() {
		return noStudentinClass;
	}

	public void setNoStudentinClass(int noStudentinClass) {
		this.noStudentinClass = noStudentinClass;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public StudentDetail(Long id, String college, int noStudentinClass, String location) {
		super();
		this.id = id;
		this.college = college;
		this.noStudentinClass = noStudentinClass;
		this.location = location;
	}
    
}