package com.HibernateOneToOne.ServiceLayer;

import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.HibernateOneToOne.PojoClasses.Address;
import com.HibernateOneToOne.PojoClasses.CollegeDetails;
import com.HibernateOneToOne.PojoClasses.Student;
import com.HibernateOneToOne.PojoClasses.StudentDetail;
import com.HibernateOneToOne.Repository.AddressRepo;
import com.HibernateOneToOne.Repository.Repository;
import com.HibernateOneToOne.Repository.collegeDetailsRepo;

@Service
public class ServiceImple implements ServiceClass {
	
	@Autowired
	private Repository repo;
	
	@Autowired
	private AddressRepo addrepo;
	
	@Autowired
	private collegeDetailsRepo collRepo;

	@Override
	public Student saveStudent(Student student) {
		if (student != null) {
			Student save = repo.save(student);
			return save;
		}
		return null;
	}

	@Override
	public List<Student> getAllRecords() {
		List<Student> users = repo.findAll();
		return users;
	}

	@Override
	public String deleteRecord(Long id) {
		boolean existsById = repo.existsById(id);
		if (existsById) {
			repo.deleteById(id);
			return "Your delete with Id " + id + " deleted.";
		}
		return "Your delete with Id " + id + "Not Found can't delete.";
	}

	@Override
	public String updateRecord(Long id, Student student) {
		Optional<Student> findById = repo.findById(id);
		if (findById.isEmpty()) 
			return "Student Not Found";
		Student update = findById.get();
		update.setFirstName(student.getFirstName());
		update.setLastName(student.getLastName());
		update.setFatherName(student.getFatherName());
		update.setId(id);
	
		repo.save(update); 
		 return "Student Details Updated Sucessfully";
			}
	
	
	@Override
	public Student saveStudentDetails(Long id, StudentDetail studentDetails) {
		Optional<Student> findById = repo.findById(id);
		if (findById.isEmpty()) {
			throw new RuntimeException("User Not Found");
		}
		Student userEntity = findById.get();
		userEntity.setStudentDetail(studentDetails);
		repo.save(userEntity);
		return userEntity;
	}

	
	@Override
	public Student addAddress(Long id, Address address) {
		Optional<Student> findById = repo.findById(id);
		if (findById.isEmpty()) {
			throw new RuntimeException("User Not Found");
		}
		Student user = findById.get();
		address.setStudent(user);
		addrepo.save(address);
		return user;
	}
	

	@Override
	public String saveCollegeData(CollegeDetails collegeDetails) {

		if (collegeDetails != null) {
			collRepo.save(collegeDetails);
			return "College Data is Added successfully";
		}

		return "College data is empty please full the details.!";
	}
	

	@Override
	public Student assignUserToCollege(Long id, Long collegeId) {

		Optional<Student> findById = repo.findById(id);
		Optional<CollegeDetails> collegeExists = collRepo.findById(collegeId);
		
		if (findById.isEmpty()) 
			throw new RuntimeException("user not found with the id " + id);
		if (collegeExists.isEmpty())
			throw new RuntimeException("College Not found with the id " + collegeId);
		
		Student userEntity = findById.get();
		CollegeDetails collegeDetails = collegeExists.get();

		Set<CollegeDetails> college = new HashSet<>();

		college.add(collegeDetails);

		userEntity.setCollegeDetails(college);
		repo.save(userEntity);

		return userEntity;
	}
	
}