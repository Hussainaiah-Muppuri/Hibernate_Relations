package com.HibernateOneToOne.ServiceLayer;

import java.util.List;

import com.HibernateOneToOne.PojoClasses.Address;
import com.HibernateOneToOne.PojoClasses.CollegeDetails;
import com.HibernateOneToOne.PojoClasses.Student;
import com.HibernateOneToOne.PojoClasses.StudentDetail;

public interface ServiceClass {
	
	public List<Student> getAllRecords();
	
	public String deleteRecord(Long id);
	
	public String updateRecord(Long id, Student user);
	
	public Student saveStudent(Student student);
	
	public Student saveStudentDetails(Long id, StudentDetail studentDetails);

    public Student addAddress(Long id, Address address);

	Student assignUserToCollege(Long id, Long collegeId);

	String saveCollegeData(CollegeDetails collegeDetails);	

}
