package com.HibernateOneToOne.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.HibernateOneToOne.PojoClasses.Address;
import com.HibernateOneToOne.PojoClasses.CollegeDetails;
import com.HibernateOneToOne.PojoClasses.Student;
import com.HibernateOneToOne.PojoClasses.StudentDetail;
import com.HibernateOneToOne.ServiceLayer.ServiceClass;


@RestController
public class ControllerClass {
	
	@Autowired
	private ServiceClass service;

	
	@PostMapping("/address/{userId}")
	public Student addAddress(@PathVariable Long id,@RequestBody Address address) {
		Student user = service.addAddress(id, address);
		return user;
	}
	
	@PostMapping("/details/{id}")
	public Student addStudentDetails(@PathVariable Long id, @RequestBody StudentDetail studentDetails) {
		Student user= service.saveStudentDetails(id,studentDetails);
		return user;
	}
	
	
	@PostMapping("/")
	public ResponseEntity<Student> saveData(@RequestBody Student student) {
		if (student != null) {
			Student userEntity = service.saveStudent(student);
			if (userEntity != null) {
				return new ResponseEntity<>(userEntity, HttpStatus.OK);
			} else {
				return new ResponseEntity<>(null, HttpStatus.BAD_REQUEST);
			}
		} else {
			return new ResponseEntity<>(null, HttpStatus.BAD_REQUEST);
		}
	}

	
	@GetMapping("/")
	public ResponseEntity<List<Student>> getAllRecords() {
		List<Student> allRecords = service.getAllRecords();

		return new ResponseEntity<>(allRecords, HttpStatus.OK);
	}

	
	@DeleteMapping("/{id}")
	public ResponseEntity<String>  deleteRecord(@PathVariable Long id) {
		String deleteRecord = service.deleteRecord(id);
      return new ResponseEntity<>(deleteRecord,HttpStatus.OK);
	}
	

	@PutMapping("/{id}")
	public String  updateRecord(@PathVariable Long id,@RequestBody Student student) {	
		String update = service.updateRecord(id, student);
		return update;
	}
	
	
	@PostMapping("/collegeDetails")
	public String addCollegeDetails(@RequestBody CollegeDetails collegeDetails) {
		String user = service.saveCollegeData(collegeDetails);
		return user;
	}
	
	
	@PostMapping("/student/{id}/{collegeId}")
	public Student assignStudentToCollege(@PathVariable Long id,@PathVariable Long collegeId) {
		Student assignUserToCollege = service.assignUserToCollege(id, collegeId);
		return assignUserToCollege;
	}
	
}