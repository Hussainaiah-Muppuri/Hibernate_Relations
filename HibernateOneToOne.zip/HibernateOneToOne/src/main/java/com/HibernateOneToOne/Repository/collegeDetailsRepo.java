package com.HibernateOneToOne.Repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.HibernateOneToOne.PojoClasses.CollegeDetails;

@Repository
public interface collegeDetailsRepo extends JpaRepository<CollegeDetails, Long>{

}
