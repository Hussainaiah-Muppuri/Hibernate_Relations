package com.HibernateOneToOne.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.HibernateOneToOne.PojoClasses.Student;

@org.springframework.stereotype.Repository
public interface Repository extends JpaRepository<Student, Long>{

}
