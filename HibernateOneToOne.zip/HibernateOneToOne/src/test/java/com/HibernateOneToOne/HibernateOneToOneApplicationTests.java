package com.HibernateOneToOne;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HibernateOneToOneApplicationTests {

	@Test
	void contextLoads() {
	}

}
